package com.example.myapplication;

import android.app.Application;

import java.util.ArrayList;

public class MyApplication extends Application {
    ArrayList<modal> arr = new ArrayList<>();
    @Override
    public void onCreate(){
        super.onCreate();
    }

    public ArrayList<modal> getDataList(){
        return arr;
    }

    public void addData(modal Modal) {
        arr.add(Modal);

    }
    public MyApplication getInstance(){
        return this;
    }
}
