package com.example.myapplication;

import java.io.Serializable;
import java.util.ArrayList;

public class ModalResponse implements Serializable {
     ArrayList<modal> dataList;
    public ArrayList<modal> getItemBeans(){
        return dataList;
    }
    public void setItemBeans(ArrayList<modal> list){
        dataList = list;
    }
}
