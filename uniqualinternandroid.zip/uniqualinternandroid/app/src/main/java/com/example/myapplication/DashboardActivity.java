package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.TextView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity{

    MyApplication myApplication1;
    static recyclerAdapter recyclerAdapter1;
    RecyclerView recyclerView1;


    ArrayList<modal> arrayList = new ArrayList<modal>();


    private TextView AddItem,logout;


//    @Override
//    protected void onPostResume() {
//        try {
//            Intent intent1 = getIntent();
//            Bundle args = intent1.getBundleExtra("BUNDLE");
//            ArrayList<modal> object = (ArrayList<modal>) args.getSerializable("ARRAYLIST");
//            Log.d("hello", object.toString());
//
//        } catch (Exception e) {}
//        super.onPostResume();
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        myApplication1 = (MyApplication) getApplication();


        AddItem = (TextView) findViewById(R.id.txt12);
        recyclerView1 = findViewById(R.id.recycle);
        logout = (TextView) findViewById(R.id.txt10);
        // Toast.makeText(getApplicationContext(),mb.getPrice(),Toast.LENGTH_LONG).show();

        AddItem.setOnClickListener(v -> {
            Intent intent =new Intent(DashboardActivity.this,AddIItemActivity.class);
            Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });
        setItemRv();
        logout.setOnClickListener(v -> {
            MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(this);
            materialAlertDialogBuilder.setTitle(R.string.logout);
            materialAlertDialogBuilder.setMessage(R.string.logoutmsg);
            materialAlertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent2 = new Intent(DashboardActivity.this,MainActivity.class);
                    Toast.makeText(getApplicationContext(),"Going back to Login Screen", Toast.LENGTH_SHORT).show();
                    startActivity(intent2);
                    SharedPreferences SharedPreferences = getSharedPreferences(getResources().getString(R.string.app_name),MODE_PRIVATE);
                    SharedPreferences.Editor sharedPreferenceeditor = SharedPreferences.edit();
                    sharedPreferenceeditor.clear();
                    sharedPreferenceeditor.apply();
                    finish();

                }
            });
            materialAlertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            materialAlertDialogBuilder.show();



        });

    }
    private void setItemRv(){
        recyclerAdapter1 = new recyclerAdapter(this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        recyclerView1.setLayoutManager(linearLayoutManager);
        recyclerView1.setAdapter( recyclerAdapter1);

    }

    @Override
    protected void onResume(){
        super.onResume();
        if(recyclerAdapter1 != null)
        {
            SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.app_name), MODE_PRIVATE);
            String dataText = sharedPreferences.getString(constants.itemdata, "");

            try{

                ModalResponse modalResponse1 = new Gson().fromJson(dataText, new TypeToken<ModalResponse>(){}.getType());
                myApplication1.getInstance().getDataList().clear();
                myApplication1.getInstance().getDataList().addAll(modalResponse1.getItemBeans());
                recyclerAdapter1.clearList();
                recyclerAdapter1.addToList(modalResponse1.getItemBeans());

            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
