package com.example.myapplication;

public class constants {

    public static final String islogin = "islogin";
    public static final String email = "email";
    public static final String password = "password";
    public static final String itemdata = "ITEM_DATA";
    public static final String editdata = "Edit_Data";


}
