package com.example.myapplication;

public class ContactModel {
    public String title, price;

    public ContactModel(String title,String price){
        this.title = title;
        this.price = price;
    }
}
