package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private EditText edtemail,edtpassword;
    private TextView login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = (TextView) findViewById(R.id.txt7);
        edtemail = (EditText) findViewById(R.id.txt4);
        edtpassword = (EditText) findViewById(R.id.txt5);

        checkloginbutton(false);
        login.setOnClickListener(v -> {
            String email = edtemail.getText().toString();
            String password = edtpassword.getText().toString();

            if(Patterns.EMAIL_ADDRESS.matcher(email).matches())
            {
                if(password.length()>=8)
                {

                    SharedPreferences SharedPreferences = getSharedPreferences(getResources().getString(R.string.app_name),MODE_PRIVATE);
                    SharedPreferences.Editor sharedPreferenceeditor = SharedPreferences.edit();
                    sharedPreferenceeditor.putBoolean(constants.islogin,true);
                    sharedPreferenceeditor.putString(constants.email,email);
                    sharedPreferenceeditor.putString(constants.password,password);
                    sharedPreferenceeditor.apply();

                    Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this,DashboardActivity.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_SHORT).show();

                }
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_SHORT).show();
            }
        });
        edtemail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validate();

            }
        });

         edtpassword.addTextChangedListener(new TextWatcher() {
             @Override
             public void beforeTextChanged(CharSequence s, int start, int count, int after) {

             }

             @Override
             public void onTextChanged(CharSequence s, int start, int before, int count) {

             }

             @Override
             public void afterTextChanged(Editable s) {
                 validate();

             }
         });

    }



    private void checkloginbutton(boolean isEnable)
    {
        if(isEnable) {
            login.setEnabled(true);
            login.setBackground(ContextCompat.getDrawable(MainActivity.this,R.drawable.ic_bg_red_9));
        }
        else
        {
            login.setEnabled(false);
            login.setBackground(ContextCompat.getDrawable(MainActivity.this,R.drawable.ic_bg_light_red_9));
        }
    }

    private void validate(){
        String email = edtemail.getText().toString();
        String password = edtpassword.getText().toString();
        if(Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            checkloginbutton(password.length()>=8);
        }
        else
        {
            checkloginbutton(false);
        }
    }
}