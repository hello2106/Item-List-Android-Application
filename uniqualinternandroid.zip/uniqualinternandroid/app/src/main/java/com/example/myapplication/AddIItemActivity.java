package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;


public class AddIItemActivity extends AppCompatActivity {

     TextView back,save,delete,dashtxt;
     RecyclerView recyclerView;
     EditText price1, title1;
    ArrayList<modal> arrayList = new ArrayList<modal>();
    MyApplication myApplication2 ;
    recyclerAdapter recyclerAdapter2;
    boolean isEdit ;
    String modalDataBean;
    modal editData ;
    modal editData1 ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_items);
        myApplication2 = (MyApplication) getApplication();
        dashtxt = findViewById(R.id.additem);
        title1 = findViewById(R.id.title1);
        price1 = findViewById(R.id.price1);
        save = findViewById(R.id.save);
        back = findViewById(R.id.back);
        delete = findViewById(R.id.delete);
        isEdit = getIntent().hasExtra(constants.editdata);
        modalDataBean = getIntent().getStringExtra(constants.editdata);
        back.setOnClickListener(v ->{
            MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(this);
            materialAlertDialogBuilder.setTitle(R.string.back);
            materialAlertDialogBuilder.setMessage(R.string.backmsg);
            materialAlertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent1 = new Intent(AddIItemActivity.this,DashboardActivity.class);
                    Toast.makeText(getApplicationContext(),"Going Back",Toast.LENGTH_SHORT).show();
                    startActivity(intent1);
                    finish();

                }
            });
            materialAlertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            materialAlertDialogBuilder.show();

        });

        if(isEdit)
        {
            editData = new Gson().fromJson(modalDataBean, new TypeToken<modal>(){}.getType());
            dashtxt.setText(R.string.edit_item);
            delete.setVisibility(View.VISIBLE);
            title1.setText(editData.getTitle());
            price1.setText(editData.getPrice());

        }

        delete.setOnClickListener(v ->{

            MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(this);
            materialAlertDialogBuilder.setTitle(R.string.deleteconformation);
            materialAlertDialogBuilder.setMessage(R.string.deletemsg);
            materialAlertDialogBuilder.setPositiveButton(R.string.yes,new DialogInterface.OnClickListener(){

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    for(int i=0;i<myApplication2.getInstance().getDataList().size();i++)
                    {
                        modal temp = myApplication2.getInstance().getDataList().get(i);
                        if(temp.getId() == editData.getId())
                        {
                            long h = temp.getId();
                            try {
                                myApplication2.arr.remove(i);
                            }
                            catch (IndexOutOfBoundsException e)
                            {
                                e.printStackTrace();
                            }

                            DashboardActivity.recyclerAdapter1.notifyItemRemoved(i);
                            ModalResponse modalResponse2 = new ModalResponse();
                            modalResponse2.setItemBeans(myApplication2.getInstance().getDataList());

                            SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.app_name), MODE_PRIVATE);
                            SharedPreferences.Editor myEdit = sharedPreferences.edit();
                            editData1 = new Gson().fromJson(modalDataBean, new TypeToken<modal>(){}.getType());
                            if(temp.getId() == editData1.getId())
                            {
                                myEdit.remove(String.valueOf(temp.getId()));
                            }
                            myEdit.putString(constants.itemdata,new Gson().toJson(modalResponse2));
                            myEdit.apply();

                            Intent intent = new Intent(AddIItemActivity.this,DashboardActivity.class);
                            startActivity(intent);
                            finish();

                        }


                    }

                }
            } );
            materialAlertDialogBuilder.setNegativeButton(R.string.no,new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
                });
            materialAlertDialogBuilder.setCancelable(false);
            materialAlertDialogBuilder.show();
        });




        save.setOnClickListener(c ->{
            if(isEdit)
            {
                MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(this);
                materialAlertDialogBuilder.setTitle(R.string.edittitle);
                materialAlertDialogBuilder.setMessage(R.string.editmsg);
                materialAlertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for(int i=0;i<myApplication2.getInstance().getDataList().size();i++)
                        {
                            modal temp = myApplication2.getInstance().getDataList().get(i);
                            if(temp.getId() == editData.getId())
                            {
                                editData.setTitle(title1.getText().toString());
                                editData.setPrice(price1.getText().toString());
                                myApplication2.arr.set(i,editData);
                                DashboardActivity.recyclerAdapter1.notifyItemChanged(i);

                                ModalResponse modalResponse2 = new ModalResponse();
                                modalResponse2.setItemBeans(myApplication2.getInstance().getDataList());

                                SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.app_name), MODE_PRIVATE);
                                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                                myEdit.putString(constants.itemdata,new Gson().toJson(modalResponse2));
                                myEdit.apply();
                                finish();
                            }
                        }

                    }
                });
                materialAlertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                materialAlertDialogBuilder.show();

            }
            else if(isValid())
            {
                modal Modal1 = new modal();
                Modal1.setId((System.currentTimeMillis()/1000));
                Modal1.setTitle(title1.getText().toString());
                Modal1.setPrice(price1.getText().toString());
                myApplication2.getInstance().addData(Modal1);


                ModalResponse modalResponse2 = new ModalResponse();
                modalResponse2.setItemBeans(myApplication2.getInstance().getDataList());

                SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.app_name), MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.putString(constants.itemdata,new Gson().toJson(modalResponse2));
                myEdit.apply();
                finish();



            }


        });


    }
    private boolean isValid() {

        boolean ValidTitle;
        boolean ValidPrice;

        ValidTitle = !title1.getText().toString().isEmpty();

        ValidPrice = !price1.getText().toString().isEmpty();

        return ValidTitle && ValidPrice;
    }

}
