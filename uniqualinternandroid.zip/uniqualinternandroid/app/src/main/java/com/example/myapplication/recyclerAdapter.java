package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.ItemsViewholder> {
    ArrayList<modal> arrayList = new ArrayList<>();
    Context context;

    public  recyclerAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public ItemsViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_file3,parent,false);
        return new ItemsViewholder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull ItemsViewholder holder, int position) {
        modal array = arrayList.get(position);
         String  withDollarPrice = "$" + array.getPrice();
        holder.title.setText(array.getTitle());
        holder.price.setText(withDollarPrice);

        holder.itemView.setOnClickListener(v ->{
            Intent intent = new Intent(context,AddIItemActivity.class);
            intent.putExtra(constants.editdata,new Gson().toJson(array));
            context.startActivity(intent);

        });





    }

    @Override
    public int getItemCount() {

        return arrayList.size();
    }
    public void addData(modal Modal) {
        int newposition = arrayList.size();
        arrayList.add(Modal);
        notifyItemInserted(newposition);
    }
    public void clearList(){
        arrayList.clear();
        notifyDataSetChanged();
    }
    public void addToList(ArrayList<modal> newlist){
        if (newlist == null){
            newlist = new ArrayList<>();
        }
        int newposition = arrayList.size();
        arrayList.addAll(newlist);
        notifyItemRangeChanged(newposition,arrayList.size());
    }

    public class ItemsViewholder extends RecyclerView.ViewHolder{
        TextView title,price;
        public ItemsViewholder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.txt_item);
            price = itemView.findViewById(R.id.txt_price);

        }
    }
}
